// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "XiSandboxApp",
    platforms: [
        .macOS(.v14)
    ],
    products: [
        .executable(name: "XiSandboxApp",
                    targets: ["XiSandboxApp"])
    ],
    targets: [
        .executableTarget(
            name: "XiSandboxApp"
        )
    ]
)
