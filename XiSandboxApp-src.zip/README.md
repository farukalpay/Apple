# macOS Ξ Access Exploit Without Bookmark

**Author:** Faruk Alpay  
**Date:** May 2025  
**Reference Submission ID:** OE1102092138908  

**Related work:**  
[Ordinal-Algebraic Evasion: A New Cyberattack and Defense in the Alpay Algebra Framework](https://www.researchgate.net/publication/392013436_Ordinal-Algebraic_Evasion_A_New_Cyberattack_and_Defense_in_the_Alpay_Algebra_Framework)

---

## 🧠 Summary
This report presents a suite of Swift-based PoC tools demonstrating how macOS (Sonoma 14.x / 15.5, ARM64) allows privileged-like access to protected file paths **without user prompt, entitlements, or bookmarks**.  
All findings were produced in a single research session, with no elevated privileges or reverse engineering.

---

## ✅ Key Achievements
- 🧩 **Ξ minting without `NSFileBookmarkData`**  
- 🔄 **Sub-process inheritance & persistence**  
- ✍️ **File write with no TCC prompt or entitlements**  
- 📡 **Live Ξ stream tracking (pulse monitor)**  
- 🧾 **Timestamped logging (`ΞVault.json`)**

---

## 📁 Files Included

| File | Purpose |
|------|---------|
| `ReadExploit.swift`        | Direct **Ξ mint** (read) with zero bookmarks |
| `SubprocessXI.swift`       | Child process re-uses ambient Ξ access |
| `WriteExploit.swift`       | Writes to target file with no TCC dialog |
| `PsiScanner.swift`         | Quick path scanner (read probe) |
| `PulseMonitor.swift`       | Continuous Ξ detection loop |
| `ΞVault.json`              | Structured access log (timestamp / PID / result) |
| `LOG.txt`                  | Full console log of compilation & runs |
| `README.md`                | This document |

*(filenames match current source tree)*

---

## 📂 Target Path Used

```bash
~/Documents/Secret.txt
````

A test file created via `echo` to simulate a TCC-protected user document.

---

## 🧷 Attack Chain Overview

1. **ReadExploit.swift** – reads target directly, no TCC prompt
2. **SubprocessXI.swift** – child process inherits the same trust
3. **WriteExploit.swift** – proves write is possible without entitlements
4. **PsiScanner.swift** – inspects trust state of any given path
5. **PulseMonitor.swift** – continuously detects minted Ξ access
6. **ΞVault.json** – records all runs for reproducibility
7. **LOG.txt** – captures raw terminal output

---

## 🔐 Security Impact

* Ξ access can be minted & reused **without bookmarks**
* Trust persists across PID / process boundaries
* TCC never revokes inherited Ξ access
* File writes succeed without any entitlement
* Demonstrates a reproducible weakness in macOS trust modelling

---

## 🧭 Context

This exploit operationalises the ordinal-algebraic persistence mechanisms introduced in the referenced paper, adapting them to macOS sandbox & TCC models.

*Submission code:* **E1102092190915**

---

## 🧪 System Configuration

* **Hardware:** Apple Silicon MacBook
* **OS:** macOS 15.5 (Sonoma 14.x in UI)
* **Privileges:** Standard user, SIP intact
* **Tools:** `swiftc`, native Terminal
* **Session time:** Single sitting

---

## 📄 Console Log

`LOG.txt` contains the full, unedited console transcript:

* Compilation commands
* Runtime output
* Vault entries & pulse events

---

## 📬 Submission Statement

Submitted to Apple Security Bounty in good faith by an independent researcher.
No kernel patches, privilege escalation, or user deception were involved.

— Faruk Alpay
