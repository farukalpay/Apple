import Foundation

// MARK: - Yardım
@inline(__always)
func usageAndExit() -> Never {
    print("""
    usage:
      XiSandboxApp write      <file_path>          # sandbox-write PoC
      XiSandboxApp read       <file_path>          # bookmark-free read PoC
      XiSandboxApp subprocess <file_path>          # read in child process
      XiSandboxApp pulse      <file_path> [sec]    # live monitor loop
      XiSandboxApp scan       <file_path>          # static scanner
    """)
    exit(1)
}

// MARK: - Argüman denetimi
let argv = CommandLine.arguments
guard argv.count >= 3 else { usageAndExit() }

let cmd  = argv[1]
let path = argv[2]

// MARK: - Yönlendirme
switch cmd {

case "write":
    WriteExploit.run(path: path)

case "read":
    ReadExploit.run(path: path)

case "subprocess":
    runSubprocessAccess(targetPath: path)

case "pulse":
    let interval = argv.count >= 4 ? UInt32(argv[3]) ?? 3 : 3
    XiPulseMonitor.run(path: path, interval: interval)

case "scan":
    PsiScanner.run(path: path)

default:
    print("✖︎ unknown command: \(cmd)\n")
    usageAndExit()
}
