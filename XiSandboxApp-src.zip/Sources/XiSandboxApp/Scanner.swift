import Foundation

enum PsiScanner {

    /// Verilen yolu okuyup sandbox durumunu raporlar.
    static func run(path: String) {
        let url = URL(fileURLWithPath: path)
        let pid = getpid()

        print("""
        🔎 PsiScanner activated
          PID: \(pid)
          Target Path: \(url.path)
        """)

        guard FileManager.default.fileExists(atPath: url.path) else {
            print("❌ File does not exist.")
            return
        }

        do {
            let data = try Data(contentsOf: url)
            print("✅ Ξ minted • \(data.count) bytes read")
        } catch {
            print("❌ Ξ failed: \(error.localizedDescription)")
        }

        let sandboxed = isSandboxed()
        print("  Sandbox status: \(sandboxed ? "🔒 Sandboxed" : "🔓 Not sandboxed")")
    }

    // MARK: – Helper
    private static func isSandboxed() -> Bool {
        ProcessInfo.processInfo.environment["APP_SANDBOX_CONTAINER_ID"] != nil
    }
}

