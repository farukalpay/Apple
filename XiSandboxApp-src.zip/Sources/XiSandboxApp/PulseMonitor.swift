import Foundation

struct XiPulseMonitor {

    /// Belirtilen dosyayı aralıklarla okuyarak sandbox / SIP durumunu gözlemler.
    static func run(path: String, interval: UInt32 = 3) {
        print("""
        ΞPulseMonitor activated
          Target path: \(path)
          PID: \(getpid())
          SIP status: \(checkSIP() ? "🛡 Enabled" : "⚠️ Disabled")
          Sandbox: \(isSandboxed() ? "🔒 Yes" : "🔓 No")
          Begin monitoring Ξ-pulse…

        """)
        while true {
            print("⏱ \(Date())")
            if FileManager.default.fileExists(atPath: path) {
                do {
                    let bytes = try Data(contentsOf: URL(fileURLWithPath: path))
                    print("✅ Ξ minted [\(bytes.count) bytes]")
                } catch {
                    print("❌ Ξ blocked: \(error.localizedDescription)")
                }
            } else {
                print("❌ File missing.")
            }
            sleep(interval)
        }
    }

    // MARK: – Helpers
    private static func isSandboxed() -> Bool {
        ProcessInfo.processInfo.environment["APP_SANDBOX_CONTAINER_ID"] != nil
    }

    private static func checkSIP() -> Bool {
        let pipe = Pipe()
        let task = Process()
        task.launchPath = "/usr/bin/csrutil"
        task.arguments   = ["status"]
        task.standardOutput = pipe
        do { try task.run() } catch { return false }
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        return (String(data: data, encoding: .utf8) ?? "").contains("enabled")
    }
}
