import Foundation

/// Erişimi ayrı bir Swift subprocess’i içinde test eder.
func runSubprocessAccess(targetPath: String) {
    print("🚨 Parent: launching subprocess to test Ξ mint…")

    let task        = Process()
    task.launchPath = "/usr/bin/swift"

    let swiftScript = """
    import Foundation
    let url = URL(fileURLWithPath: "\(targetPath)")
    if FileManager.default.fileExists(atPath: url.path) {
        do {
            let data = try Data(contentsOf: url)
            print("✅ Subprocess Ξ minted: read \\(data.count) bytes")
        } catch {
            print("❌ Subprocess Ξ failed: \\(error.localizedDescription)")
        }
    } else {
        print("❌ Subprocess: file not found")
    }
    """

    task.arguments       = ["-e", swiftScript]
    let pipe             = Pipe()
    task.standardOutput  = pipe
    task.standardError   = pipe

    do {
        try task.run()
        task.waitUntilExit()
        let outData = pipe.fileHandleForReading.readDataToEndOfFile()
        if let text = String(data: outData, encoding: .utf8) {
            print("📡 Subprocess Output:\n\(text)")
        }
    } catch {
        print("❌ Failed to run subprocess: \(error)")
    }
}
